﻿namespace CheckSQL_History
{
    partial class frmCheckSQL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckSQL));
            this.PenalMain = new System.Windows.Forms.TableLayoutPanel();
            this.PenalContent = new System.Windows.Forms.TableLayoutPanel();
            this.PanelTop = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PanelServer1Top = new System.Windows.Forms.TableLayoutPanel();
            this.panelServer1TopRight = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtHost1 = new System.Windows.Forms.TextBox();
            this.txtPort1 = new System.Windows.Forms.TextBox();
            this.txtServerID1 = new System.Windows.Forms.TextBox();
            this.txtUser1 = new System.Windows.Forms.TextBox();
            this.txtPassword1 = new System.Windows.Forms.TextBox();
            this.txtShema1 = new System.Windows.Forms.TextBox();
            this.cmbStatement1 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbFrom1 = new System.Windows.Forms.ComboBox();
            this.cmbTo1 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbFrom1_2 = new System.Windows.Forms.ComboBox();
            this.cmbTo1_2 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbTransaction1 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRefresh1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.lbHost1 = new System.Windows.Forms.Label();
            this.lbPort1 = new System.Windows.Forms.Label();
            this.lbServerID1 = new System.Windows.Forms.Label();
            this.lbUser1 = new System.Windows.Forms.Label();
            this.lbPassword1 = new System.Windows.Forms.Label();
            this.lbShema1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PanelServer2Top = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.txtPassword2 = new System.Windows.Forms.TextBox();
            this.txtUser2 = new System.Windows.Forms.TextBox();
            this.txtServerID2 = new System.Windows.Forms.TextBox();
            this.txtPort2 = new System.Windows.Forms.TextBox();
            this.txtHost2 = new System.Windows.Forms.TextBox();
            this.txtShema2 = new System.Windows.Forms.TextBox();
            this.cmbStatement2 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbFrom2 = new System.Windows.Forms.ComboBox();
            this.cmbTo2 = new System.Windows.Forms.ComboBox();
            this.cmbFrom2_2 = new System.Windows.Forms.ComboBox();
            this.cmbTo2_2 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbTransaction2 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRefresh2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.lbHost2 = new System.Windows.Forms.Label();
            this.lbPort2 = new System.Windows.Forms.Label();
            this.lbServerID2 = new System.Windows.Forms.Label();
            this.lbUser2 = new System.Windows.Forms.Label();
            this.lbPassword2 = new System.Windows.Forms.Label();
            this.lbShema2 = new System.Windows.Forms.Label();
            this.PanalBottom = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbCompareResult = new System.Windows.Forms.Label();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCompare = new System.Windows.Forms.Button();
            this.PenalMain.SuspendLayout();
            this.PenalContent.SuspendLayout();
            this.PanelTop.SuspendLayout();
            this.panel1.SuspendLayout();
            this.PanelServer1Top.SuspendLayout();
            this.panelServer1TopRight.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.panel2.SuspendLayout();
            this.PanelServer2Top.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.PanalBottom.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // PenalMain
            // 
            this.PenalMain.ColumnCount = 3;
            this.PenalMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.PenalMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PenalMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.PenalMain.Controls.Add(this.PenalContent, 1, 1);
            this.PenalMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PenalMain.Location = new System.Drawing.Point(0, 0);
            this.PenalMain.Name = "PenalMain";
            this.PenalMain.RowCount = 3;
            this.PenalMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PenalMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PenalMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PenalMain.Size = new System.Drawing.Size(1017, 806);
            this.PenalMain.TabIndex = 0;
            // 
            // PenalContent
            // 
            this.PenalContent.ColumnCount = 1;
            this.PenalContent.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PenalContent.Controls.Add(this.PanelTop, 0, 0);
            this.PenalContent.Controls.Add(this.PanalBottom, 0, 1);
            this.PenalContent.Controls.Add(this.tableLayoutPanel6, 0, 2);
            this.PenalContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PenalContent.Location = new System.Drawing.Point(13, 23);
            this.PenalContent.Name = "PenalContent";
            this.PenalContent.RowCount = 3;
            this.PenalContent.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.PenalContent.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29.21053F));
            this.PenalContent.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.92105F));
            this.PenalContent.Size = new System.Drawing.Size(991, 760);
            this.PenalContent.TabIndex = 0;
            // 
            // PanelTop
            // 
            this.PanelTop.ColumnCount = 3;
            this.PanelTop.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.PanelTop.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PanelTop.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.PanelTop.Controls.Add(this.panel1, 0, 0);
            this.PanelTop.Controls.Add(this.panel2, 2, 0);
            this.PanelTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelTop.Location = new System.Drawing.Point(3, 3);
            this.PanelTop.Name = "PanelTop";
            this.PanelTop.RowCount = 1;
            this.PanelTop.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanelTop.Size = new System.Drawing.Size(985, 449);
            this.PanelTop.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.PanelServer1Top);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(476, 443);
            this.panel1.TabIndex = 0;
            // 
            // PanelServer1Top
            // 
            this.PanelServer1Top.ColumnCount = 4;
            this.PanelServer1Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.PanelServer1Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.PanelServer1Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.PanelServer1Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.PanelServer1Top.Controls.Add(this.panelServer1TopRight, 1, 1);
            this.PanelServer1Top.Controls.Add(this.tableLayoutPanel1, 3, 1);
            this.PanelServer1Top.Controls.Add(this.label4, 1, 0);
            this.PanelServer1Top.Controls.Add(this.tableLayoutPanel8, 2, 1);
            this.PanelServer1Top.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelServer1Top.Location = new System.Drawing.Point(0, 0);
            this.PanelServer1Top.Name = "PanelServer1Top";
            this.PanelServer1Top.RowCount = 2;
            this.PanelServer1Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PanelServer1Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanelServer1Top.Size = new System.Drawing.Size(474, 441);
            this.PanelServer1Top.TabIndex = 2;
            // 
            // panelServer1TopRight
            // 
            this.panelServer1TopRight.ColumnCount = 1;
            this.panelServer1TopRight.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panelServer1TopRight.Controls.Add(this.label5, 0, 0);
            this.panelServer1TopRight.Controls.Add(this.label6, 0, 1);
            this.panelServer1TopRight.Controls.Add(this.label7, 0, 2);
            this.panelServer1TopRight.Controls.Add(this.label8, 0, 3);
            this.panelServer1TopRight.Controls.Add(this.label9, 0, 4);
            this.panelServer1TopRight.Controls.Add(this.label18, 0, 5);
            this.panelServer1TopRight.Controls.Add(this.label10, 0, 9);
            this.panelServer1TopRight.Controls.Add(this.label21, 0, 6);
            this.panelServer1TopRight.Controls.Add(this.label22, 0, 7);
            this.panelServer1TopRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelServer1TopRight.Location = new System.Drawing.Point(13, 23);
            this.panelServer1TopRight.Name = "panelServer1TopRight";
            this.panelServer1TopRight.RowCount = 10;
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.620115F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.288572F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.957029F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.620115F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.957029F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.142858F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.28916F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.66265F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.9759F));
            this.panelServer1TopRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panelServer1TopRight.Size = new System.Drawing.Size(81, 415);
            this.panelServer1TopRight.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 35);
            this.label5.TabIndex = 0;
            this.label5.Text = "Host";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(3, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 34);
            this.label6.TabIndex = 1;
            this.label6.Text = "Port";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(3, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 33);
            this.label7.TabIndex = 2;
            this.label7.Text = "Server ID";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(3, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 35);
            this.label8.TabIndex = 3;
            this.label8.Text = "User";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(3, 137);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 33);
            this.label9.TabIndex = 4;
            this.label9.Text = "Password";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(3, 170);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 38);
            this.label18.TabIndex = 5;
            this.label18.Text = "Shema";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 353);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 62);
            this.label10.TabIndex = 5;
            this.label10.Text = "Transaction";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 208);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 29);
            this.label21.TabIndex = 5;
            this.label21.Text = "Statements";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(3, 237);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 51);
            this.label22.TabIndex = 5;
            this.label22.Text = "Limit Hour";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.txtHost1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtPort1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtServerID1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtUser1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtPassword1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtShema1, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.cmbStatement1, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel10, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel13, 0, 8);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(125, 23);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.856927F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.175624F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.516275F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.856927F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.175624F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.856927F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.197577F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.512196F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.36585F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.14634F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(346, 415);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // txtHost1
            // 
            this.txtHost1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtHost1.Location = new System.Drawing.Point(3, 3);
            this.txtHost1.Name = "txtHost1";
            this.txtHost1.Size = new System.Drawing.Size(176, 20);
            this.txtHost1.TabIndex = 0;
            this.txtHost1.Text = "10.32.110.117";
            // 
            // txtPort1
            // 
            this.txtPort1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtPort1.Location = new System.Drawing.Point(3, 39);
            this.txtPort1.Name = "txtPort1";
            this.txtPort1.Size = new System.Drawing.Size(176, 20);
            this.txtPort1.TabIndex = 1;
            this.txtPort1.Text = "1521";
            // 
            // txtServerID1
            // 
            this.txtServerID1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtServerID1.Location = new System.Drawing.Point(3, 73);
            this.txtServerID1.Name = "txtServerID1";
            this.txtServerID1.Size = new System.Drawing.Size(176, 20);
            this.txtServerID1.TabIndex = 2;
            this.txtServerID1.Text = "GISDB1";
            // 
            // txtUser1
            // 
            this.txtUser1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtUser1.Location = new System.Drawing.Point(3, 108);
            this.txtUser1.Name = "txtUser1";
            this.txtUser1.Size = new System.Drawing.Size(176, 20);
            this.txtUser1.TabIndex = 3;
            this.txtUser1.Text = "ides";
            // 
            // txtPassword1
            // 
            this.txtPassword1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtPassword1.Location = new System.Drawing.Point(3, 144);
            this.txtPassword1.Name = "txtPassword1";
            this.txtPassword1.Size = new System.Drawing.Size(176, 20);
            this.txtPassword1.TabIndex = 4;
            this.txtPassword1.Text = "ides";
            this.txtPassword1.UseSystemPasswordChar = true;
            // 
            // txtShema1
            // 
            this.txtShema1.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtShema1.Location = new System.Drawing.Point(3, 178);
            this.txtShema1.Name = "txtShema1";
            this.txtShema1.Size = new System.Drawing.Size(176, 20);
            this.txtShema1.TabIndex = 5;
            this.txtShema1.Text = "IDES";
            // 
            // cmbStatement1
            // 
            this.cmbStatement1.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmbStatement1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatement1.FormattingEnabled = true;
            this.cmbStatement1.Items.AddRange(new object[] {
            "",
            "INSERT",
            "SELECT",
            "UPDATE",
            "DELETE"});
            this.cmbStatement1.Location = new System.Drawing.Point(3, 214);
            this.cmbStatement1.Name = "cmbStatement1";
            this.cmbStatement1.Size = new System.Drawing.Size(144, 21);
            this.cmbStatement1.TabIndex = 6;
            this.cmbStatement1.SelectedIndexChanged += new System.EventHandler(this.cmbStatement1_SelectedIndexChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.63879F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.63879F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.64348F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.74061F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.63772F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.63772F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.0629F));
            this.tableLayoutPanel2.Controls.Add(this.cmbFrom1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbTo1, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label26, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label27, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label28, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbFrom1_2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbTo1_2, 5, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 252);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(340, 33);
            this.tableLayoutPanel2.TabIndex = 11;
            // 
            // cmbFrom1
            // 
            this.cmbFrom1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbFrom1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrom1.FormattingEnabled = true;
            this.cmbFrom1.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbFrom1.Location = new System.Drawing.Point(3, 3);
            this.cmbFrom1.Name = "cmbFrom1";
            this.cmbFrom1.Size = new System.Drawing.Size(47, 21);
            this.cmbFrom1.TabIndex = 7;
            this.cmbFrom1.SelectedIndexChanged += new System.EventHandler(this.cmbFrom1_SelectedIndexChanged);
            // 
            // cmbTo1
            // 
            this.cmbTo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTo1.FormattingEnabled = true;
            this.cmbTo1.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbTo1.Location = new System.Drawing.Point(191, 3);
            this.cmbTo1.Name = "cmbTo1";
            this.cmbTo1.Size = new System.Drawing.Size(47, 21);
            this.cmbTo1.TabIndex = 8;
            this.cmbTo1.SelectedIndexChanged += new System.EventHandler(this.cmbTo1_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(155, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(30, 33);
            this.label26.TabIndex = 13;
            this.label26.Text = "To";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(109, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 33);
            this.label27.TabIndex = 14;
            this.label27.Text = "HH:SS";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(297, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 33);
            this.label28.TabIndex = 15;
            this.label28.Text = "HH:SS";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbFrom1_2
            // 
            this.cmbFrom1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbFrom1_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrom1_2.Enabled = false;
            this.cmbFrom1_2.FormattingEnabled = true;
            this.cmbFrom1_2.Items.AddRange(new object[] {
            "",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "59"});
            this.cmbFrom1_2.Location = new System.Drawing.Point(56, 3);
            this.cmbFrom1_2.Name = "cmbFrom1_2";
            this.cmbFrom1_2.Size = new System.Drawing.Size(47, 21);
            this.cmbFrom1_2.TabIndex = 16;
            this.cmbFrom1_2.SelectedIndexChanged += new System.EventHandler(this.cmbFrom1_2_SelectedIndexChanged);
            // 
            // cmbTo1_2
            // 
            this.cmbTo1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTo1_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTo1_2.Enabled = false;
            this.cmbTo1_2.FormattingEnabled = true;
            this.cmbTo1_2.Items.AddRange(new object[] {
            "",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "59"});
            this.cmbTo1_2.Location = new System.Drawing.Point(244, 3);
            this.cmbTo1_2.Name = "cmbTo1_2";
            this.cmbTo1_2.Size = new System.Drawing.Size(47, 21);
            this.cmbTo1_2.TabIndex = 17;
            this.cmbTo1_2.SelectedIndexChanged += new System.EventHandler(this.cmbTo1_2_SelectedIndexChanged);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Controls.Add(this.cmbTransaction1, 0, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 354);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(340, 58);
            this.tableLayoutPanel10.TabIndex = 12;
            // 
            // cmbTransaction1
            // 
            this.cmbTransaction1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTransaction1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTransaction1.FormattingEnabled = true;
            this.cmbTransaction1.Location = new System.Drawing.Point(3, 3);
            this.cmbTransaction1.Name = "cmbTransaction1";
            this.cmbTransaction1.Size = new System.Drawing.Size(334, 21);
            this.cmbTransaction1.TabIndex = 8;
            this.cmbTransaction1.SelectedIndexChanged += new System.EventHandler(this.cmbTransaction1_SelectedIndexChanged);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.btnRefresh1, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 291);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(340, 57);
            this.tableLayoutPanel13.TabIndex = 13;
            // 
            // btnRefresh1
            // 
            this.btnRefresh1.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnRefresh1.Location = new System.Drawing.Point(188, 3);
            this.btnRefresh1.Name = "btnRefresh1";
            this.btnRefresh1.Size = new System.Drawing.Size(149, 33);
            this.btnRefresh1.TabIndex = 9;
            this.btnRefresh1.Text = "Refresh";
            this.btnRefresh1.UseVisualStyleBackColor = true;
            this.btnRefresh1.Click += new System.EventHandler(this.btnRefresh1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Server 1";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.lbHost1, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.lbPort1, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.lbServerID1, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.lbUser1, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.lbPassword1, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.lbShema1, 0, 5);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(100, 23);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 11;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.469055F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.81759F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.143323F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.794788F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.857142F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.714286F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.857143F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.98371F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.583062F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.32298F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(19, 415);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // lbHost1
            // 
            this.lbHost1.AutoSize = true;
            this.lbHost1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbHost1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHost1.ForeColor = System.Drawing.Color.Red;
            this.lbHost1.Location = new System.Drawing.Point(3, 0);
            this.lbHost1.Name = "lbHost1";
            this.lbHost1.Size = new System.Drawing.Size(13, 35);
            this.lbHost1.TabIndex = 0;
            this.lbHost1.Text = "*";
            this.lbHost1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbHost1.Visible = false;
            // 
            // lbPort1
            // 
            this.lbPort1.AutoSize = true;
            this.lbPort1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbPort1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPort1.ForeColor = System.Drawing.Color.Red;
            this.lbPort1.Location = new System.Drawing.Point(3, 35);
            this.lbPort1.Name = "lbPort1";
            this.lbPort1.Size = new System.Drawing.Size(13, 32);
            this.lbPort1.TabIndex = 0;
            this.lbPort1.Text = "*";
            this.lbPort1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPort1.Visible = false;
            // 
            // lbServerID1
            // 
            this.lbServerID1.AutoSize = true;
            this.lbServerID1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbServerID1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbServerID1.ForeColor = System.Drawing.Color.Red;
            this.lbServerID1.Location = new System.Drawing.Point(3, 67);
            this.lbServerID1.Name = "lbServerID1";
            this.lbServerID1.Size = new System.Drawing.Size(13, 34);
            this.lbServerID1.TabIndex = 0;
            this.lbServerID1.Text = "*";
            this.lbServerID1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbServerID1.Visible = false;
            // 
            // lbUser1
            // 
            this.lbUser1.AutoSize = true;
            this.lbUser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbUser1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser1.ForeColor = System.Drawing.Color.Red;
            this.lbUser1.Location = new System.Drawing.Point(3, 101);
            this.lbUser1.Name = "lbUser1";
            this.lbUser1.Size = new System.Drawing.Size(13, 36);
            this.lbUser1.TabIndex = 0;
            this.lbUser1.Text = "*";
            this.lbUser1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbUser1.Visible = false;
            // 
            // lbPassword1
            // 
            this.lbPassword1.AutoSize = true;
            this.lbPassword1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbPassword1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword1.ForeColor = System.Drawing.Color.Red;
            this.lbPassword1.Location = new System.Drawing.Point(3, 137);
            this.lbPassword1.Name = "lbPassword1";
            this.lbPassword1.Size = new System.Drawing.Size(13, 37);
            this.lbPassword1.TabIndex = 0;
            this.lbPassword1.Text = "*";
            this.lbPassword1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPassword1.Visible = false;
            // 
            // lbShema1
            // 
            this.lbShema1.AutoSize = true;
            this.lbShema1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbShema1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbShema1.ForeColor = System.Drawing.Color.Red;
            this.lbShema1.Location = new System.Drawing.Point(3, 174);
            this.lbShema1.Name = "lbShema1";
            this.lbShema1.Size = new System.Drawing.Size(13, 32);
            this.lbShema1.TabIndex = 0;
            this.lbShema1.Text = "*";
            this.lbShema1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbShema1.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.PanelServer2Top);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(505, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(477, 443);
            this.panel2.TabIndex = 1;
            // 
            // PanelServer2Top
            // 
            this.PanelServer2Top.ColumnCount = 4;
            this.PanelServer2Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.PanelServer2Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.PanelServer2Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.PanelServer2Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.PanelServer2Top.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.PanelServer2Top.Controls.Add(this.tableLayoutPanel4, 3, 1);
            this.PanelServer2Top.Controls.Add(this.label15, 1, 0);
            this.PanelServer2Top.Controls.Add(this.tableLayoutPanel9, 2, 1);
            this.PanelServer2Top.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelServer2Top.Location = new System.Drawing.Point(0, 0);
            this.PanelServer2Top.Name = "PanelServer2Top";
            this.PanelServer2Top.RowCount = 2;
            this.PanelServer2Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PanelServer2Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanelServer2Top.Size = new System.Drawing.Size(475, 441);
            this.PanelServer2Top.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label19, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label17, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label24, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label25, 0, 7);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(13, 23);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 10;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.097855F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.772676F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.435266F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.110085F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.435266F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.435266F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.42857F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.28572F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.35505F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(82, 415);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 33);
            this.label11.TabIndex = 0;
            this.label11.Text = "Host";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(3, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 36);
            this.label12.TabIndex = 0;
            this.label12.Text = "Port";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(3, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 35);
            this.label13.TabIndex = 0;
            this.label13.Text = "Server ID";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(3, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 37);
            this.label14.TabIndex = 0;
            this.label14.Text = "User";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(3, 141);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 35);
            this.label16.TabIndex = 0;
            this.label16.Text = "Password";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(3, 176);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(76, 35);
            this.label19.TabIndex = 0;
            this.label19.Text = "Shema";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(3, 354);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 61);
            this.label17.TabIndex = 0;
            this.label17.Text = "Transaction";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(3, 211);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 29);
            this.label24.TabIndex = 1;
            this.label24.Text = "Statements";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(3, 240);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 47);
            this.label25.TabIndex = 1;
            this.label25.Text = "Limit Hour";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.txtPassword2, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtUser2, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtServerID2, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtPort2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtHost2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtShema2, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.cmbStatement2, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel11, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel14, 0, 8);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(126, 23);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 10;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.76421F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.76421F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.101294F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.090039F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.090039F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.427124F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.857142F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.714286F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.71429F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.00651F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(346, 415);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // txtPassword2
            // 
            this.txtPassword2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtPassword2.Location = new System.Drawing.Point(3, 145);
            this.txtPassword2.Name = "txtPassword2";
            this.txtPassword2.Size = new System.Drawing.Size(176, 20);
            this.txtPassword2.TabIndex = 4;
            this.txtPassword2.Text = "ides";
            this.txtPassword2.UseSystemPasswordChar = true;
            // 
            // txtUser2
            // 
            this.txtUser2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtUser2.Location = new System.Drawing.Point(3, 112);
            this.txtUser2.Name = "txtUser2";
            this.txtUser2.Size = new System.Drawing.Size(176, 20);
            this.txtUser2.TabIndex = 3;
            this.txtUser2.Text = "ides";
            // 
            // txtServerID2
            // 
            this.txtServerID2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtServerID2.Location = new System.Drawing.Point(3, 75);
            this.txtServerID2.Name = "txtServerID2";
            this.txtServerID2.Size = new System.Drawing.Size(176, 20);
            this.txtServerID2.TabIndex = 2;
            this.txtServerID2.Text = "GISDB1";
            // 
            // txtPort2
            // 
            this.txtPort2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtPort2.Location = new System.Drawing.Point(3, 39);
            this.txtPort2.Name = "txtPort2";
            this.txtPort2.Size = new System.Drawing.Size(176, 20);
            this.txtPort2.TabIndex = 1;
            this.txtPort2.Text = "1521";
            // 
            // txtHost2
            // 
            this.txtHost2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtHost2.Location = new System.Drawing.Point(3, 3);
            this.txtHost2.Name = "txtHost2";
            this.txtHost2.Size = new System.Drawing.Size(176, 20);
            this.txtHost2.TabIndex = 0;
            this.txtHost2.Text = "10.32.110.117";
            // 
            // txtShema2
            // 
            this.txtShema2.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtShema2.Location = new System.Drawing.Point(3, 178);
            this.txtShema2.Name = "txtShema2";
            this.txtShema2.Size = new System.Drawing.Size(176, 20);
            this.txtShema2.TabIndex = 5;
            this.txtShema2.Text = "IDES";
            // 
            // cmbStatement2
            // 
            this.cmbStatement2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmbStatement2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatement2.FormattingEnabled = true;
            this.cmbStatement2.Items.AddRange(new object[] {
            "",
            "INSERT",
            "SELECT",
            "UPDATE",
            "DELETE"});
            this.cmbStatement2.Location = new System.Drawing.Point(3, 213);
            this.cmbStatement2.Name = "cmbStatement2";
            this.cmbStatement2.Size = new System.Drawing.Size(144, 21);
            this.cmbStatement2.TabIndex = 6;
            this.cmbStatement2.SelectedIndexChanged += new System.EventHandler(this.cmbStatement2_SelectedIndexChanged);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 7;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.9028F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.9028F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.60882F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.467009F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.9028F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.9028F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.31297F));
            this.tableLayoutPanel5.Controls.Add(this.label29, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label30, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label31, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.cmbFrom2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.cmbTo2, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.cmbFrom2_2, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.cmbTo2_2, 5, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 249);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(340, 34);
            this.tableLayoutPanel5.TabIndex = 14;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(157, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 34);
            this.label29.TabIndex = 0;
            this.label29.Text = "To";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(111, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 34);
            this.label30.TabIndex = 1;
            this.label30.Text = "HH:SS";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(297, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 34);
            this.label31.TabIndex = 2;
            this.label31.Text = "HH:SS";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbFrom2
            // 
            this.cmbFrom2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbFrom2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrom2.FormattingEnabled = true;
            this.cmbFrom2.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbFrom2.Location = new System.Drawing.Point(3, 3);
            this.cmbFrom2.Name = "cmbFrom2";
            this.cmbFrom2.Size = new System.Drawing.Size(48, 21);
            this.cmbFrom2.TabIndex = 10;
            this.cmbFrom2.SelectedIndexChanged += new System.EventHandler(this.cmbFrom2_SelectedIndexChanged);
            // 
            // cmbTo2
            // 
            this.cmbTo2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTo2.FormattingEnabled = true;
            this.cmbTo2.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbTo2.Location = new System.Drawing.Point(189, 3);
            this.cmbTo2.Name = "cmbTo2";
            this.cmbTo2.Size = new System.Drawing.Size(48, 21);
            this.cmbTo2.TabIndex = 11;
            this.cmbTo2.SelectedIndexChanged += new System.EventHandler(this.cmbTo2_SelectedIndexChanged);
            // 
            // cmbFrom2_2
            // 
            this.cmbFrom2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbFrom2_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrom2_2.Enabled = false;
            this.cmbFrom2_2.FormattingEnabled = true;
            this.cmbFrom2_2.Items.AddRange(new object[] {
            "",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "59"});
            this.cmbFrom2_2.Location = new System.Drawing.Point(57, 3);
            this.cmbFrom2_2.Name = "cmbFrom2_2";
            this.cmbFrom2_2.Size = new System.Drawing.Size(48, 21);
            this.cmbFrom2_2.TabIndex = 12;
            this.cmbFrom2_2.SelectedIndexChanged += new System.EventHandler(this.cmbFrom2_2_SelectedIndexChanged);
            // 
            // cmbTo2_2
            // 
            this.cmbTo2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTo2_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTo2_2.Enabled = false;
            this.cmbTo2_2.FormattingEnabled = true;
            this.cmbTo2_2.Items.AddRange(new object[] {
            "",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "59"});
            this.cmbTo2_2.Location = new System.Drawing.Point(243, 3);
            this.cmbTo2_2.Name = "cmbTo2_2";
            this.cmbTo2_2.Size = new System.Drawing.Size(48, 21);
            this.cmbTo2_2.TabIndex = 13;
            this.cmbTo2_2.SelectedIndexChanged += new System.EventHandler(this.cmbTo2_2_SelectedIndexChanged);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Controls.Add(this.cmbTransaction2, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 354);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(340, 58);
            this.tableLayoutPanel11.TabIndex = 15;
            // 
            // cmbTransaction2
            // 
            this.cmbTransaction2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbTransaction2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTransaction2.FormattingEnabled = true;
            this.cmbTransaction2.Location = new System.Drawing.Point(3, 3);
            this.cmbTransaction2.Name = "cmbTransaction2";
            this.cmbTransaction2.Size = new System.Drawing.Size(334, 21);
            this.cmbTransaction2.TabIndex = 13;
            this.cmbTransaction2.SelectedIndexChanged += new System.EventHandler(this.cmbTransaction2_SelectedIndexChanged);
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 1;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel14.Controls.Add(this.btnRefresh2, 0, 0);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 289);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(340, 59);
            this.tableLayoutPanel14.TabIndex = 16;
            // 
            // btnRefresh2
            // 
            this.btnRefresh2.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnRefresh2.Location = new System.Drawing.Point(188, 3);
            this.btnRefresh2.Name = "btnRefresh2";
            this.btnRefresh2.Size = new System.Drawing.Size(149, 35);
            this.btnRefresh2.TabIndex = 12;
            this.btnRefresh2.Text = "Refresh";
            this.btnRefresh2.UseVisualStyleBackColor = true;
            this.btnRefresh2.Click += new System.EventHandler(this.btnRefresh2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 20);
            this.label15.TabIndex = 2;
            this.label15.Text = "Server 2";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.lbHost2, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.lbPort2, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.lbServerID2, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.lbUser2, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.lbPassword2, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.lbShema2, 0, 5);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(101, 23);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 11;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.469055F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.469055F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.794788F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.81759F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.794788F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.469055F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.469055F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.863192F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.037267F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.795031F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.32919F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(19, 415);
            this.tableLayoutPanel9.TabIndex = 3;
            // 
            // lbHost2
            // 
            this.lbHost2.AutoSize = true;
            this.lbHost2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbHost2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHost2.ForeColor = System.Drawing.Color.Red;
            this.lbHost2.Location = new System.Drawing.Point(3, 0);
            this.lbHost2.Name = "lbHost2";
            this.lbHost2.Size = new System.Drawing.Size(13, 35);
            this.lbHost2.TabIndex = 0;
            this.lbHost2.Text = "*";
            this.lbHost2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbHost2.Visible = false;
            // 
            // lbPort2
            // 
            this.lbPort2.AutoSize = true;
            this.lbPort2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbPort2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPort2.ForeColor = System.Drawing.Color.Red;
            this.lbPort2.Location = new System.Drawing.Point(3, 35);
            this.lbPort2.Name = "lbPort2";
            this.lbPort2.Size = new System.Drawing.Size(13, 35);
            this.lbPort2.TabIndex = 0;
            this.lbPort2.Text = "*";
            this.lbPort2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPort2.Visible = false;
            // 
            // lbServerID2
            // 
            this.lbServerID2.AutoSize = true;
            this.lbServerID2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbServerID2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbServerID2.ForeColor = System.Drawing.Color.Red;
            this.lbServerID2.Location = new System.Drawing.Point(3, 70);
            this.lbServerID2.Name = "lbServerID2";
            this.lbServerID2.Size = new System.Drawing.Size(13, 36);
            this.lbServerID2.TabIndex = 0;
            this.lbServerID2.Text = "*";
            this.lbServerID2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbServerID2.Visible = false;
            // 
            // lbUser2
            // 
            this.lbUser2.AutoSize = true;
            this.lbUser2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbUser2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser2.ForeColor = System.Drawing.Color.Red;
            this.lbUser2.Location = new System.Drawing.Point(3, 106);
            this.lbUser2.Name = "lbUser2";
            this.lbUser2.Size = new System.Drawing.Size(13, 32);
            this.lbUser2.TabIndex = 0;
            this.lbUser2.Text = "*";
            this.lbUser2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbUser2.Visible = false;
            // 
            // lbPassword2
            // 
            this.lbPassword2.AutoSize = true;
            this.lbPassword2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbPassword2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword2.ForeColor = System.Drawing.Color.Red;
            this.lbPassword2.Location = new System.Drawing.Point(3, 138);
            this.lbPassword2.Name = "lbPassword2";
            this.lbPassword2.Size = new System.Drawing.Size(13, 36);
            this.lbPassword2.TabIndex = 0;
            this.lbPassword2.Text = "*";
            this.lbPassword2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPassword2.Visible = false;
            // 
            // lbShema2
            // 
            this.lbShema2.AutoSize = true;
            this.lbShema2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbShema2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbShema2.ForeColor = System.Drawing.Color.Red;
            this.lbShema2.Location = new System.Drawing.Point(3, 174);
            this.lbShema2.Name = "lbShema2";
            this.lbShema2.Size = new System.Drawing.Size(13, 35);
            this.lbShema2.TabIndex = 0;
            this.lbShema2.Text = "*";
            this.lbShema2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbShema2.Visible = false;
            // 
            // PanalBottom
            // 
            this.PanalBottom.ColumnCount = 1;
            this.PanalBottom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanalBottom.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.PanalBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanalBottom.Location = new System.Drawing.Point(3, 458);
            this.PanalBottom.Name = "PanalBottom";
            this.PanalBottom.RowCount = 1;
            this.PanalBottom.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanalBottom.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 215F));
            this.PanalBottom.Size = new System.Drawing.Size(985, 215);
            this.PanalBottom.TabIndex = 1;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial;
            this.tableLayoutPanel12.ColumnCount = 3;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.92748F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.940756F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.02962F));
            this.tableLayoutPanel12.Controls.Add(this.richTextBox2, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.richTextBox1, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(979, 209);
            this.tableLayoutPanel12.TabIndex = 2;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(505, 8);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(466, 193);
            this.richTextBox2.TabIndex = 16;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.richTextBox1.Location = new System.Drawing.Point(8, 8);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(463, 193);
            this.richTextBox1.TabIndex = 15;
            this.richTextBox1.Text = "";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.03046F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.96954F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel15, 1, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 679);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(985, 78);
            this.tableLayoutPanel6.TabIndex = 2;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.22222F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.77778F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.lbCompareResult, 1, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(801, 72);
            this.tableLayoutPanel7.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "Compare Result";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCompareResult
            // 
            this.lbCompareResult.AutoSize = true;
            this.lbCompareResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbCompareResult.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCompareResult.ForeColor = System.Drawing.Color.Red;
            this.lbCompareResult.Location = new System.Drawing.Point(184, 3);
            this.lbCompareResult.Name = "lbCompareResult";
            this.lbCompareResult.Size = new System.Drawing.Size(611, 66);
            this.lbCompareResult.TabIndex = 2;
            this.lbCompareResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel15.Controls.Add(this.btnCompare, 0, 1);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(810, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 3;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.27778F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.61111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(172, 72);
            this.tableLayoutPanel15.TabIndex = 5;
            // 
            // btnCompare
            // 
            this.btnCompare.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCompare.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompare.Location = new System.Drawing.Point(3, 13);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(166, 46);
            this.btnCompare.TabIndex = 5;
            this.btnCompare.Text = "COMPARE";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // frmCheckSQL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 806);
            this.Controls.Add(this.PenalMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1033, 844);
            this.Name = "frmCheckSQL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SQL HISTORY COMPARE TOOL";
            this.Load += new System.EventHandler(this.frmCheckSQL_Load);
            this.PenalMain.ResumeLayout(false);
            this.PenalContent.ResumeLayout(false);
            this.PanelTop.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.PanelServer1Top.ResumeLayout(false);
            this.PanelServer1Top.PerformLayout();
            this.panelServer1TopRight.ResumeLayout(false);
            this.panelServer1TopRight.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.PanelServer2Top.ResumeLayout(false);
            this.PanelServer2Top.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.PanalBottom.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel PenalMain;
        private System.Windows.Forms.TableLayoutPanel PenalContent;
        private System.Windows.Forms.TableLayoutPanel PanelTop;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel PanelServer1Top;
        private System.Windows.Forms.TableLayoutPanel panelServer1TopRight;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TableLayoutPanel PanelServer2Top;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnRefresh1;
        private System.Windows.Forms.TextBox txtHost1;
        private System.Windows.Forms.TextBox txtPort1;
        private System.Windows.Forms.TextBox txtServerID1;
        private System.Windows.Forms.TextBox txtUser1;
        private System.Windows.Forms.TextBox txtPassword1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbTransaction2;
        private System.Windows.Forms.TextBox txtPassword2;
        private System.Windows.Forms.TextBox txtUser2;
        private System.Windows.Forms.TextBox txtServerID2;
        private System.Windows.Forms.TextBox txtPort2;
        private System.Windows.Forms.TextBox txtHost2;
        private System.Windows.Forms.Button btnRefresh2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtShema1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtShema2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label lbHost2;
        private System.Windows.Forms.Label lbPort2;
        private System.Windows.Forms.Label lbServerID2;
        private System.Windows.Forms.Label lbUser2;
        private System.Windows.Forms.Label lbPassword2;
        private System.Windows.Forms.Label lbShema2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbTransaction1;
        private System.Windows.Forms.ComboBox cmbStatement1;
        private System.Windows.Forms.ComboBox cmbFrom1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbStatement2;
        private System.Windows.Forms.ComboBox cmbFrom2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ComboBox cmbTo1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbTo2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label lbHost1;
        private System.Windows.Forms.Label lbPort1;
        private System.Windows.Forms.Label lbServerID1;
        private System.Windows.Forms.Label lbUser1;
        private System.Windows.Forms.Label lbPassword1;
        private System.Windows.Forms.Label lbShema1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.ComboBox cmbFrom1_2;
        private System.Windows.Forms.ComboBox cmbTo1_2;
        private System.Windows.Forms.ComboBox cmbFrom2_2;
        private System.Windows.Forms.ComboBox cmbTo2_2;
        private System.Windows.Forms.TableLayoutPanel PanalBottom;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbCompareResult;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
    }
}

