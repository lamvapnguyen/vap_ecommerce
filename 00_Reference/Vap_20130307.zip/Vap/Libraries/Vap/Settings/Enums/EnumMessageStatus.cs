﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vap.Settings.Enums
{
    /// <summary>
    /// To get the status of each dto.
    /// </summary>
    public enum EnumMessageStatus
    {
        Success,
        Error
    }
}
