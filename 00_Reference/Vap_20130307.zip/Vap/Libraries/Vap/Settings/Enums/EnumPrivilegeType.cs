﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vap.Settings.Enums
{
    /// <summary>
    /// To define the right type to access to the function of the user.
    /// </summary>
    public enum EnumPrivilegeType
    {
        NoAccess,
        ReadOnly,
        FullAccess
    }
}
