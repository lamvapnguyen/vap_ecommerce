﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vap.Settings.Enums
{
    /// <summary>
    /// To check is the object is exist or not.
    /// </summary>
    public enum EnumChecking
    {
        NotExited,
        Exited,
        ExitedButDeleted
    }
}
