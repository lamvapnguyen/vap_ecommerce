﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vap.Data.Mapping;
//using log4net;

namespace Vap.Web.Controllers
{
    public class TestController : Controller
    {
        //private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
       
        //
        // GET: /Test/

        public ActionResult Index()
        {
           return View();
        }

    }
}
