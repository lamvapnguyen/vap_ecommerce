﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vap.Helpers
{
    public static class GlobalVariables
    {
        #region declare global variable
        public static int defaultPageSize = 2;

        #endregion declare global variable
    }
}
