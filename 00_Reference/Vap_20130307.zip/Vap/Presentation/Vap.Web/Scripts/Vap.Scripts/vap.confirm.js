/*
 *Date Create: 2012/11/22
 * Create by: Nguyen Tien Lam
 *Description: To show confirm message befor saving data.
 */
function showConfirmDialog() {
    return confirm('Confirm saving this record?');
}

